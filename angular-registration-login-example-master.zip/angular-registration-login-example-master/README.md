angular-registration-login-example
==============================

AngularJS User Registration and Login Example

To see a demo and further details go to http://jasonwatmore.com/post/2015/03/10/AngularJS-User-Registration-and-Login-Example.aspx
